package cat.copernic.ericbeltran.bdserveis.models

import android.os.Build
import androidx.annotation.RequiresApi
import java.io.Serializable
import java.time.LocalDateTime

class Usuari @RequiresApi(Build.VERSION_CODES.O) constructor(
    var uidCliente: String,
    var NomComplert: String,
    var correu: String,
    var gender: String,
    var dataNaixement: String,
    var nif: String,
    var countryCode: String,
    var numeroTelefon: String,
    var comandas: Comandas
) : Serializable