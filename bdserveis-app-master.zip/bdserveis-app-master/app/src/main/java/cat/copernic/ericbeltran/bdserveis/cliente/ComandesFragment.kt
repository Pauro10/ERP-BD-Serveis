package cat.copernic.ericbeltran.bdserveis.cliente

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.ericbeltran.bdserveis.adapters.ComandasAdapter
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentComandesBinding
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*


class ComandesFragment : Fragment() {

    private lateinit var bindingComandes: FragmentComandesBinding

    private lateinit var comandesAdapter: ComandasAdapter

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private var nombreClienteTemp = ""
    private var uidClienteTemp = ""


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val binding = FragmentComandesBinding.inflate(inflater, container, false)
        bindingComandes = binding

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")

        this.bindingComandes.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        initComandesRecycler()

        return binding.root
    }

    private fun initComandesRecycler() {
        this.bindingComandes.rvComandes.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        this.comandesAdapter = ComandasAdapter(requireContext())
        this.bindingComandes.rvComandes.adapter = this.comandesAdapter

        return observeData()
    }

    fun fetchGestionComandas(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        if (auth.currentUser!!.uid == "my3s7XE0g7UsaSInM5AW9d2Di8u1") {
            getDatosComandaAdmin().observeForever { datosList ->
                mutableData.value = datosList
            }
        } else {
            getDatosComanda().observeForever { datosList ->
                mutableData.value = datosList
            }
        }
        return mutableData
    }

    private fun observeData() {
        fetchGestionComandas().observe(viewLifecycleOwner, Observer {
            comandesAdapter.setListData(it)
            comandesAdapter.notifyDataSetChanged()
        })
    }

    private fun getDatosComanda(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        val listData = mutableListOf<Usuari>()
        val cliente: FirebaseUser = auth.currentUser!!
        dbReference.orderByKey().limitToFirst(1).equalTo(cliente.uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { comanda ->
                        val referenciaComandas =
                            comanda.key.let { dbReference.child(it!!).child("comandas") }
                        referenciaComandas.addListenerForSingleValueEvent(object :
                            ValueEventListener {
                            override fun onDataChange(snapshot: DataSnapshot) {
                                snapshot.children.forEach { idComanda ->
                                    val referenciaIDcomanda =
                                        idComanda.key.let { referenciaComandas.child(it!!) }
                                    Log.w("referenciaIDComanda", referenciaIDcomanda.toString())
                                    referenciaIDcomanda.addListenerForSingleValueEvent(object :
                                        ValueEventListener {
                                        override fun onDataChange(snapshot: DataSnapshot) {
                                            val idComanda =
                                                snapshot.key.let { referenciaIDcomanda.child(it!!) }.key
                                            val fechaComanda =
                                                snapshot.child("fecha").value.toString()
                                            val estadoComanda =
                                                snapshot.child("estado").value.toString()
                                            val costeComanda =
                                                snapshot.child("coste").value.toString()

                                            if (fechaComanda == "null" && estadoComanda == "null" && costeComanda == "null") {
                                                referenciaIDcomanda.removeValue()
                                            } else {

                                                val datosClientes = Usuari(
                                                    user.uid, "", "", "",
                                                    "", "", "",
                                                    "", Comandas(
                                                        idComanda.toString(),
                                                        estadoComanda,
                                                        costeComanda,
                                                        fechaComanda,
                                                        Producto(
                                                            "", "",
                                                            "", "",
                                                            "",
                                                            ""
                                                        ),
                                                    )
                                                )
                                                when (estadoComanda) {
                                                    "Pendent" -> {
                                                        var pendent =
                                                            bindingComandes.txtNumPendent.text.toString()
                                                                .toInt()
                                                        pendent += 1
                                                        bindingComandes.txtNumPendent.text =
                                                            pendent.toString()
                                                    }
                                                    "Revisió" -> {
                                                        var revisio =
                                                            bindingComandes.txtNumRevisio.text.toString()
                                                                .toInt()
                                                        revisio += 1
                                                        bindingComandes.txtNumRevisio.text =
                                                            revisio.toString()
                                                    }
                                                    "Acceptat" -> {
                                                        var acceptat =
                                                            bindingComandes.txtNumProces.text.toString()
                                                                .toInt()
                                                        acceptat += 1
                                                        bindingComandes.txtNumProces.text =
                                                            acceptat.toString()
                                                    }
                                                }

                                                listData.add(datosClientes)
                                                mutableData.value = listData
                                            }
                                        }

                                        override fun onCancelled(error: DatabaseError) {
                                            TODO("Not yet implemented")
                                        }

                                    })
                                }

                            }

                            override fun onCancelled(error: DatabaseError) {
                                TODO("Not yet implemented")
                            }
                        })
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            })
        return mutableData
    }

    private fun getDatosComandaAdmin(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        val listData = mutableListOf<Usuari>()
        dbReference.orderByKey().addListenerForSingleValueEvent(object : ValueEventListener {
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { comanda ->
                    val referenciaComandas =
                        comanda.key.let { dbReference.child(it!!).child("comandas") }
                    val uidCliente = comanda.key.let { dbReference.child(it!!) }.key
                    uidClienteTemp = uidCliente.toString()
                    Log.w("comandas", comanda.toString())
                    val nombreCliente = comanda.child("nomComplert").value.toString()
                    nombreClienteTemp = nombreCliente
                    val correu = comanda.child("correu").value.toString()
                    val gender = comanda.child("gender").value.toString()
                    val dataNaixement = comanda.child("dataNaixement").value.toString()
                    val nif = comanda.child("nif").value.toString()
                    val numeroTelefon = comanda.child("numeroTelefon").value.toString()
                    val countryCode = comanda.child("countryCode").value.toString()
                    Log.w("nombreClienteTemp", nombreClienteTemp)
                    referenciaComandas.addListenerForSingleValueEvent(object :
                        ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            snapshot.children.forEach { idComanda ->
                                val referenciaIDcomanda =
                                    idComanda.key.let { referenciaComandas.child(it!!) }
                                Log.w("referenciaIDComanda", referenciaIDcomanda.toString())
                                referenciaIDcomanda.addListenerForSingleValueEvent(object :
                                    ValueEventListener {
                                    override fun onDataChange(snapshot: DataSnapshot) {
                                        val idComanda =
                                            snapshot.key.let { referenciaIDcomanda.child(it!!) }.key
                                        val fechaComanda =
                                            snapshot.child("fecha").value.toString()
                                        val estadoComanda =
                                            snapshot.child("estado").value.toString()
                                        val costeComanda =
                                            snapshot.child("coste").value.toString()

                                        val datosClientes = Usuari(
                                            uidCliente.toString(),
                                            nombreCliente,
                                            correu,
                                            gender,
                                            dataNaixement,
                                            nif,
                                            countryCode,
                                            numeroTelefon,
                                            Comandas(
                                                idComanda.toString(),
                                                estadoComanda,
                                                costeComanda,
                                                fechaComanda,
                                                Producto("", "", "", "", "", ""),
                                            )
                                        )
                                        Log.w("estadoComanda", estadoComanda)
                                        when (estadoComanda) {
                                            "Pendent" -> {
                                                var pendent =
                                                    bindingComandes.txtNumPendent.text.toString()
                                                        .toInt()
                                                pendent += 1
                                                bindingComandes.txtNumPendent.text =
                                                    pendent.toString()
                                                Log.w("NumeroPendent", pendent.toString())
                                            }
                                            "Revisió" -> {
                                                var revisio =
                                                    bindingComandes.txtNumRevisio.text.toString()
                                                        .toInt()
                                                revisio += 1
                                                bindingComandes.txtNumRevisio.text =
                                                    revisio.toString()
                                            }
                                            "Acceptat" -> {
                                                var acceptat =
                                                    bindingComandes.txtNumProces.text.toString()
                                                        .toInt()
                                                acceptat += 1
                                                bindingComandes.txtNumProces.text =
                                                    acceptat.toString()
                                            }
                                        }

                                        listData.add(datosClientes)
                                        mutableData.value = listData
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        TODO("Not yet implemented")
                                    }

                                })
                            }

                        }

                        override fun onCancelled(error: DatabaseError) {
                            TODO("Not yet implemented")
                        }
                    })
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
        return mutableData
    }

}