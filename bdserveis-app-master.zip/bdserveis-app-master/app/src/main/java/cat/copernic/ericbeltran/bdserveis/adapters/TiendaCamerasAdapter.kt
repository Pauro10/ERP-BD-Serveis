package cat.copernic.ericbeltran.bdserveis.adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.tienda.TendaFragmentDirections
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.squareup.picasso.Picasso
import java.util.*

class TiendaCamerasAdapter(private val context: Context) :
    RecyclerView.Adapter<TiendaCamerasAdapter.ViewHolder>() {

    private var dataListCamerasProducto = mutableListOf<Producto>()

    private lateinit var user: FirebaseUser
    private lateinit var auth: FirebaseAuth

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.diseno_tienda, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentCamera = dataListCamerasProducto[position]

        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!

        val dispo = holder.itemView.findViewById<TextView>(R.id.txtDisponible)
        val color = holder.itemView.findViewById<TextView>(R.id.txtPrecio)
        val imagen = holder.itemView.findViewById<ImageView>(R.id.imgProducto)
        Picasso.get().load(currentCamera.imagenProducto).into(imagen)
        val nombre = holder.itemView.findViewById<TextView>(R.id.txtNombreProductoTienda)
        nombre.text = currentCamera.nombre.toUpperCase(Locale.ROOT)

        color.text = (currentCamera.coste + " €")
        dispo.text = currentCamera.disponibilidad.toUpperCase(Locale.ROOT)

        if (dispo.text == "DISPONIBLE") {
            dispo.setTextColor(Color.parseColor("#DD13C500"))
        } else if (dispo.text == "NO DISPONIBLE") {
            dispo.setTextColor(Color.RED)
            if (user.uid == "my3s7XE0g7UsaSInM5AW9d2Di8u1") {
                holder.itemView.findViewById<CardView>(R.id.cvProductoTienda).setOnClickListener {
                    val action = TendaFragmentDirections.actionToEditarTiendaFragment(currentCamera)
                    holder.itemView.findNavController().navigate(action)
                }
            }
        }

        if (dispo.text == "DISPONIBLE") {
            holder.itemView.findViewById<CardView>(R.id.cvProductoTienda).setOnClickListener {
                if (user.uid == "my3s7XE0g7UsaSInM5AW9d2Di8u1") {
                    val action = TendaFragmentDirections.actionToEditarTiendaFragment(currentCamera)
                    holder.itemView.findNavController().navigate(action)
                } else {
                    val action = TendaFragmentDirections.actionToInfoProducteFragment(currentCamera)
                    holder.itemView.findNavController().navigate(action)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return dataListCamerasProducto.size
    }

    fun setListData(data: MutableList<Producto>) {
        dataListCamerasProducto = data
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}