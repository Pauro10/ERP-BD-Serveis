package cat.copernic.ericbeltran.bdserveis.admin

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.adapters.InfoComandasAdapter
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInfoComandaAdminBinding
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*


class InfoComandaAdmin : Fragment() {

    private lateinit var bindingInfoComandaAdmin: FragmentInfoComandaAdminBinding

    private lateinit var infoComandasAdapter: InfoComandasAdapter

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private var pendentcomp = 0
    private var revisiocomp = 0
    private var procescomp = 0

    private val args by navArgs<InfoComandaAdminArgs>()

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentInfoComandaAdminBinding.inflate(inflater, container, false)
        bindingInfoComandaAdmin = binding

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")

        this.bindingInfoComandaAdmin.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        bindingInfoComandaAdmin.tfNom.setText(args.currentComandaAdmin.NomComplert)
        bindingInfoComandaAdmin.tfTelefon.setText(args.currentComandaAdmin.numeroTelefon)
        bindingInfoComandaAdmin.tfCorreu.setText(args.currentComandaAdmin.correu)
        bindingInfoComandaAdmin.tfPreu.setText(args.currentComandaAdmin.comandas.coste)
        bindingInfoComandaAdmin.textData.text = args.currentComandaAdmin.comandas.fecha

        comprobarEstado()

        bindingInfoComandaAdmin.btnModificar.setOnClickListener {
            modificaEstadoComanda()
        }
        initComandesRecycler()

        return binding.root
    }

    private fun comprobarEstado() {
        if (args.currentComandaAdmin.comandas.estado == "Pendent") {
            bindingInfoComandaAdmin.estatPendent.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.rojoCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.txtPendent.setTextColor(getResources().getColor(R.color.black))
        } else if (args.currentComandaAdmin.comandas.estado == "Revisió") {
            bindingInfoComandaAdmin.estatRevisio.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.amarilloCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.txtRevisio.setTextColor(getResources().getColor(R.color.black))
        } else if (args.currentComandaAdmin.comandas.estado == "Acceptat") {
            bindingInfoComandaAdmin.estatProces.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.verdeCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.txtProces.setTextColor(getResources().getColor(R.color.black))
        }

        bindingInfoComandaAdmin.estatPendent.setOnClickListener {
            bindingInfoComandaAdmin.estatPendent.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.rojoCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            pendentcomp = 1
            procescomp = 0
            revisiocomp = 0
            bindingInfoComandaAdmin.estatRevisio.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.amarillonocheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.estatProces.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.verdenocheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.txtProces.setTextColor(getResources().getColor(R.color.negronocheck))
            bindingInfoComandaAdmin.txtRevisio.setTextColor(getResources().getColor(R.color.negronocheck))
        }

        bindingInfoComandaAdmin.estatProces.setOnClickListener {
            bindingInfoComandaAdmin.estatProces.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.verdeCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            procescomp = 1
            revisiocomp = 0
            pendentcomp = 0
            bindingInfoComandaAdmin.estatPendent.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.rojonocheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.estatRevisio.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.amarillonocheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.txtPendent.setTextColor(getResources().getColor(R.color.negronocheck))
            bindingInfoComandaAdmin.txtRevisio.setTextColor(getResources().getColor(R.color.negronocheck))
        }

        bindingInfoComandaAdmin.estatRevisio.setOnClickListener {
            bindingInfoComandaAdmin.estatRevisio.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.amarilloCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            revisiocomp = 1
            pendentcomp = 0
            procescomp = 0
            bindingInfoComandaAdmin.estatPendent.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.rojonocheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.estatProces.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.verdenocheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComandaAdmin.txtProces.setTextColor(getResources().getColor(R.color.negronocheck))
            bindingInfoComandaAdmin.txtPendent.setTextColor(getResources().getColor(R.color.negronocheck))
        }
    }


    private fun initComandesRecycler() {
        this.bindingInfoComandaAdmin.rvProductes.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        this.infoComandasAdapter = InfoComandasAdapter(requireContext())
        this.bindingInfoComandaAdmin.rvProductes.adapter = this.infoComandasAdapter

        return observeData()
    }

    fun fetchGestionComandas(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        getDatosComandaProductos().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeData() {
        fetchGestionComandas().observe(viewLifecycleOwner, Observer {
            infoComandasAdapter.setListData(it)
            infoComandasAdapter.notifyDataSetChanged()
        })
    }

    private fun getDatosComandaProductos(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        val listData = mutableListOf<Usuari>()
        val uidCliente = args.currentComandaAdmin.uidCliente
        val idComanda = args.currentComandaAdmin.comandas.idComanda

        dbReference.orderByKey().limitToFirst(1).equalTo(uidCliente)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { info ->

                            val comandaQuery =
                                info.key.let { dbReference.child(it!!).child("comandas") }
                            comandaQuery.orderByKey().equalTo(idComanda)
                                .addListenerForSingleValueEvent(object :
                                    ValueEventListener {
                                    override fun onDataChange(snapshot: DataSnapshot) {
                                        snapshot.children.forEach { idComanda ->
                                            val idComandaQuery = idComanda.key.let {
                                                comandaQuery.child(it!!).child("producto")
                                            }
                                            idComandaQuery.orderByKey()
                                                .addListenerForSingleValueEvent(object :
                                                    ValueEventListener {
                                                    override fun onDataChange(snapshot: DataSnapshot) {
                                                        snapshot.children.forEach { idProducto ->
                                                            val idProductoQuery =
                                                                idProducto.key.let {
                                                                    idComandaQuery.child(it!!)
                                                                }
                                                            idProductoQuery.addValueEventListener(
                                                                object : ValueEventListener {
                                                                    override fun onDataChange(
                                                                        snapshot: DataSnapshot
                                                                    ) {
                                                                        snapshot.children.forEach { idProductoBuena ->
                                                                            val idFinal =
                                                                                idProductoBuena.key.let {
                                                                                    idProductoQuery.child(
                                                                                        it!!
                                                                                    )
                                                                                }
                                                                            idFinal.addValueEventListener(
                                                                                object :
                                                                                    ValueEventListener {
                                                                                    override fun onDataChange(
                                                                                        snapshot: DataSnapshot
                                                                                    ) {
                                                                                        val nombreProducto =
                                                                                            snapshot.child(
                                                                                                "nombre"
                                                                                            ).value.toString()
                                                                                        val costeProducto =
                                                                                            snapshot.child(
                                                                                                "coste"
                                                                                            ).value.toString()
                                                                                        val imagen = snapshot.child("imagen").value.toString()

                                                                                        val listaProductos =
                                                                                            Usuari(
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                Comandas(
                                                                                                    "",
                                                                                                    "",
                                                                                                    "",
                                                                                                    "",
                                                                                                    Producto(
                                                                                                        "",
                                                                                                        nombreProducto,
                                                                                                        costeProducto,
                                                                                                        "",
                                                                                                        "",
                                                                                                        imagen
                                                                                                    )
                                                                                                )
                                                                                            )

                                                                                        listData.add(
                                                                                            listaProductos
                                                                                        )
                                                                                        mutableData.value =
                                                                                            listData
                                                                                    }

                                                                                    override fun onCancelled(
                                                                                        error: DatabaseError
                                                                                    ) {
                                                                                        TODO("Not yet implemented")
                                                                                    }

                                                                                })
                                                                        }
                                                                    }

                                                                    override fun onCancelled(error: DatabaseError) {
                                                                        TODO("Not yet implemented")
                                                                    }

                                                                })
                                                        }
                                                    }

                                                    override fun onCancelled(error: DatabaseError) {
                                                        TODO("Not yet implemented")
                                                    }

                                                })
                                        }
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        TODO("Not yet implemented")
                                    }
                                })
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }


            })


        return mutableData
    }

    private fun modificaEstadoComanda() {
        val uidCliente = args.currentComandaAdmin.uidCliente
        val idComanda = args.currentComandaAdmin.comandas.idComanda

        dbReference.orderByKey().limitToFirst(1).equalTo(uidCliente)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { comanda ->
                            val referenciaComandas =
                                comanda.key.let { dbReference.child(it!!).child("comandas") }
                            Log.w("referenciaComandaInfo", referenciaComandas.toString())

                            referenciaComandas.orderByKey().limitToFirst(1).equalTo(idComanda)
                                .addListenerForSingleValueEvent(object : ValueEventListener {
                                    override fun onDataChange(snapshot: DataSnapshot) {
                                        if (snapshot.exists()) {
                                            snapshot.children.forEach { idComanda ->
                                                val referenciaIDcomanda =
                                                    idComanda.key.let { referenciaComandas.child(it!!) }
                                                Log.w(
                                                    "referenciaIDComandaInfo",
                                                    referenciaIDcomanda.toString()
                                                )
                                                val estatPendent = "Pendent"
                                                val estatProces = "Acceptat"
                                                val estatRevisio = "Revisió"

                                                if (pendentcomp == 1) {
                                                    referenciaIDcomanda.child("estado")
                                                        .setValue(estatPendent)
                                                } else if (procescomp == 1) {
                                                    referenciaIDcomanda.child("estado")
                                                        .setValue(estatProces)
                                                } else if (revisiocomp == 1) {
                                                    referenciaIDcomanda.child("estado")
                                                        .setValue(estatRevisio)
                                                }
                                                findNavController().navigate(R.id.action_to_comandesFragment)
                                            }

                                        }
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        TODO("Not yet implemented")
                                    }
                                })
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            })
    }

}