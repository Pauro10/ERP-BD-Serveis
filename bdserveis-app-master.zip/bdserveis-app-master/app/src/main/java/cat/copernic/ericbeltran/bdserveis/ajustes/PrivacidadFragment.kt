package cat.copernic.ericbeltran.bdserveis.ajustes

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentPrivacidadBinding

class PrivacidadFragment : DialogFragment() {

    private lateinit var bindingPriv: FragmentPrivacidadBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentPrivacidadBinding.inflate(inflater, container, false)
        bindingPriv = binding

        return binding.root
    }



}
