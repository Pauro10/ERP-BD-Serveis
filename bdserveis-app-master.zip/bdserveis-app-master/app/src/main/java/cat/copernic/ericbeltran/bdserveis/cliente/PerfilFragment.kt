package cat.copernic.ericbeltran.bdserveis.cliente

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentPerfilBinding
import cat.copernic.ericbeltran.bdserveis.isValidEmail
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import cat.copernic.ericbeltran.bdserveis.snack
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*


class PerfilFragment : Fragment() {

    private lateinit var bindingPerfil: FragmentPerfilBinding

    //Datos Firebase
    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    @RequiresApi(Build.VERSION_CODES.O)
    private var tempDatos: Usuari =
        Usuari(
            "",
            "", "", "", "", "", "", "",
            Comandas("","", "", "", Producto("","", "","","",""))
        )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val binding = FragmentPerfilBinding.inflate(inflater, container, false)
        bindingPerfil = binding

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")

        this.bindingPerfil.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        //Establecer nombre del cliente debajo de la pantalla
        perfilCliente()

        //Cambiar datos del cliente
        bindingPerfil.btnGuardarCambios.setOnClickListener {
            guardarDatos()
            requireView().snack(getString(R.string.canvisGuardats))
        }

        //Cambiar contraseña del cliente
        bindingPerfil.txtRestablecerContrasena.setOnClickListener {
            cambiarContraseña()
        }

        return binding.root
    }

    //Funcion para cargar nombre del cliente
    private fun perfilCliente() {
        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { user ->
                            val NomComplert = user.child("nomComplert").value.toString()
                            val nif = user.child("nif").value.toString()
                            val correu = user.child("correu").value.toString()
                            val numeroTelefon = user.child("numeroTelefon").value.toString()

                            tempDatos.NomComplert = NomComplert
                            tempDatos.nif = nif
                            tempDatos.correu = correu
                            tempDatos.numeroTelefon = numeroTelefon
                            cargarPerfil()
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e(getString(R.string.infoCancelar), error.toString())
                }

            })
        bindingPerfil.tfDni.isFocusable = false
        bindingPerfil.tfMail.isFocusable = false
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun cargarPerfil() {

        bindingPerfil.tfNom.setText(tempDatos.NomComplert)
        bindingPerfil.tfDni.setText(tempDatos.nif)
        bindingPerfil.tfMail.setText(tempDatos.correu)
        bindingPerfil.tfTelefon.setText(tempDatos.numeroTelefon)
    }

    private fun guardarDatos() {

        val userBD = user.uid.let { dbReference.child(it) }

        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { _ ->
                            val nombreModificado = bindingPerfil.tfNom.getText()
                            val telefonoModificado = bindingPerfil.tfTelefon.getText()

                            userBD.child("nomComplert").setValue(nombreModificado.toString())
                            userBD.child("numeroTelefon").setValue(telefonoModificado.toString())
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })
    }

    private fun cambiarContraseña() {
        val email = bindingPerfil.tfMail.getText().toString()
        if (isValidEmail(email)) {
            FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        showAlert()
                    } else {
                        view?.snack(getString(R.string.errorEnviarCorreu))
                    }
                }
        } else {
            view?.snack(getString(R.string.formatEmailInvalid))
        }
    }

    private fun showAlert() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle(getString(R.string.correuEnviatCorrecte))
        builder.setMessage(getString(R.string.revisaCorreu))
        builder.setPositiveButton(getString(R.string.infoAcceptar), null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

}