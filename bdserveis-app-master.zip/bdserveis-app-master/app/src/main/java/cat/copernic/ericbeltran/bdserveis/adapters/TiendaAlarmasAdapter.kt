package cat.copernic.ericbeltran.bdserveis.adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.tienda.TendaFragmentDirections
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.squareup.picasso.Picasso
import java.util.*

class TiendaAlarmasAdapter(private val context: Context) :
    RecyclerView.Adapter<TiendaAlarmasAdapter.ViewHolder>() {

    private lateinit var user: FirebaseUser
    private lateinit var auth: FirebaseAuth

    private var dataListAlarmasProducto = mutableListOf<Producto>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.diseno_tienda, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentAlarma = dataListAlarmasProducto[position]

        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!

        val dispo = holder.itemView.findViewById<TextView>(R.id.txtDisponible)
        val color = holder.itemView.findViewById<TextView>(R.id.txtPrecio)
        val nombre = holder.itemView.findViewById<TextView>(R.id.txtNombreProductoTienda)
        val imagen = holder.itemView.findViewById<ImageView>(R.id.imgProducto)
        Picasso.get().load(currentAlarma.imagenProducto).into(imagen)

        color.text = (currentAlarma.coste + " €")
        dispo.text = currentAlarma.disponibilidad.toUpperCase(Locale.ROOT)
        nombre.text = currentAlarma.nombre.toUpperCase(Locale.ROOT)

        if (dispo.text == "DISPONIBLE") {
            dispo.setTextColor(Color.parseColor("#DD13C500"))
        } else if (dispo.text == "NO DISPONIBLE") {
            dispo.setTextColor(Color.RED)
            if (user.uid == "my3s7XE0g7UsaSInM5AW9d2Di8u1") {
                holder.itemView.findViewById<CardView>(R.id.cvProductoTienda).setOnClickListener {
                    val action = TendaFragmentDirections.actionToEditarTiendaFragment(currentAlarma)
                    holder.itemView.findNavController().navigate(action)
                }
            }
        }

        if (dispo.text == "DISPONIBLE") {
            holder.itemView.findViewById<CardView>(R.id.cvProductoTienda).setOnClickListener {
                if (user.uid == "my3s7XE0g7UsaSInM5AW9d2Di8u1") {
                    val action = TendaFragmentDirections.actionToEditarTiendaFragment(currentAlarma)
                    holder.itemView.findNavController().navigate(action)
                } else {
                    val action = TendaFragmentDirections.actionToInfoProducteFragment(currentAlarma)
                    holder.itemView.findNavController().navigate(action)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return dataListAlarmasProducto.size
    }

    fun setListData(data: MutableList<Producto>) {
        dataListAlarmasProducto = data
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}