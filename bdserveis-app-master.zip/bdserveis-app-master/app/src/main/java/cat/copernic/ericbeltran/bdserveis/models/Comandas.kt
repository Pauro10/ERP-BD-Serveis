package cat.copernic.ericbeltran.bdserveis.models

import android.os.Build
import androidx.annotation.RequiresApi
import java.util.*

class Comandas @RequiresApi(Build.VERSION_CODES.O) constructor(
    var idComanda: String,
    var estado: String,
    var coste: String,
    var fecha: String,
    var producto: Producto
)