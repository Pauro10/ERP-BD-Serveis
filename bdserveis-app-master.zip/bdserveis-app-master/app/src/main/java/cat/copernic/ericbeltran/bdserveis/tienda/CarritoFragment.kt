package cat.copernic.ericbeltran.bdserveis.tienda

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.adapters.InfoComandasAdapter
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentCarritoBinding
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

class CarritoFragment : Fragment() {

    private lateinit var bindingCarrito: FragmentCarritoBinding

    private lateinit var infoComandasTempAdapter: InfoComandasAdapter

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private var costeTotal = 0
    private var comprovarComanda: Int = 0

    @RequiresApi(Build.VERSION_CODES.O)
    private var datosTemporales: Producto = Producto("", "", "", "", "", "")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentCarritoBinding.inflate(inflater, container, false)
        bindingCarrito = binding

        bindingCarrito.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")

        initComandesRecycler()

        bindingCarrito.tfPreu.isFocusable = false

        bindingCarrito.btnFinalitzarComanda.setOnClickListener {
            showAlert()
            finalizarComanda()
        }

        return binding.root
    }

    private fun initComandesRecycler() {
        this.bindingCarrito.listaProductosComanda.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        this.infoComandasTempAdapter = InfoComandasAdapter(requireContext())
        this.bindingCarrito.listaProductosComanda.adapter = this.infoComandasTempAdapter

        return observeData()
    }

    fun fetchGestionComandas(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        getDatosComandaProductos().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeData() {
        fetchGestionComandas().observe(viewLifecycleOwner, Observer {
            infoComandasTempAdapter.setListData(it)
            infoComandasTempAdapter.notifyDataSetChanged()
        })
    }

    private fun getDatosComandaProductos(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        val listData = mutableListOf<Usuari>()

        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { info ->

                            val comandaTempQuery =
                                info.key.let { dbReference.child(it!!).child("comandaTemp") }
                            comandaTempQuery.addListenerForSingleValueEvent(object :
                                ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    snapshot.children.forEach { idComanda ->
                                        val idComandaQuery = idComanda.key.let {
                                            comandaTempQuery.child(it!!)
                                        }
                                        Log.w("idComandaQuery", idComandaQuery.toString())
                                        idComandaQuery.addValueEventListener(object :
                                            ValueEventListener {
                                            override fun onDataChange(snapshot: DataSnapshot) {
                                                snapshot.children.forEach { idComandaIdProducto ->
                                                    val queryFinal = idComandaIdProducto.key.let {
                                                        idComandaQuery.child(it!!)
                                                    }

                                                    queryFinal.addListenerForSingleValueEvent(object :
                                                        ValueEventListener {
                                                        override fun onDataChange(snapshot: DataSnapshot) {
                                                            val idsProductos =
                                                                snapshot.child("idProducto").value.toString()
                                                            datosTemporales.idProducto =
                                                                idsProductos
                                                            val nombreProducto =
                                                                snapshot.child("nombreProducto").value.toString()
                                                            datosTemporales.nombre = nombreProducto
                                                            val costeProducto =
                                                                snapshot.child("costeProducto").value.toString()
                                                            datosTemporales.coste = costeProducto
                                                            val descripcionProducto =
                                                                snapshot.child("descripcionProducto").value.toString()
                                                            datosTemporales.descripcion =
                                                                descripcionProducto
                                                            val imagenProducto =
                                                                snapshot.child("imagenProducto").value.toString()
                                                            datosTemporales.imagenProducto =
                                                                imagenProducto

                                                            if (comprovarComanda == 0) {
                                                                costeTotal += costeProducto.toInt()
                                                                bindingCarrito.tfPreu.text =
                                                                    costeTotal.toString()
                                                            } else if (comprovarComanda == 1) {
                                                                bindingCarrito.tfPreu.text = ""
                                                                costeTotal = 0
                                                            }

                                                            val listaProductos = Usuari(
                                                                "", "", "", "", "", "", "", "",
                                                                Comandas(
                                                                    "", "", "", "", Producto(
                                                                        idsProductos,
                                                                        nombreProducto,
                                                                        costeProducto,
                                                                        descripcionProducto,
                                                                        "",
                                                                        imagenProducto
                                                                    )
                                                                )
                                                            )

                                                            listData.add(listaProductos)
                                                            mutableData.value = listData
                                                        }

                                                        override fun onCancelled(error: DatabaseError) {
                                                            TODO("Not yet implemented")
                                                        }
                                                    })
                                                }

                                            }

                                            override fun onCancelled(error: DatabaseError) {
                                                TODO("Not yet implemented")
                                            }

                                        })
                                    }
                                }

                                override fun onCancelled(error: DatabaseError) {
                                    TODO("Not yet implemented")
                                }
                            })
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }


            })
        return mutableData
    }

    private fun eliminarComandaTemp() {
        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { info ->

                            val comandaTempQuery =
                                info.key.let { dbReference.child(it!!).child("comandaTemp") }
                            comandaTempQuery.addListenerForSingleValueEvent(object :
                                ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    snapshot.children.forEach { idComanda ->
                                        val idComandaQuery = idComanda.key.let {
                                            comandaTempQuery.child(it!!)
                                        }
                                        Log.w("idComandaQuery", idComandaQuery.toString())
                                        idComandaQuery.addListenerForSingleValueEvent(object :
                                            ValueEventListener {
                                            override fun onDataChange(snapshot: DataSnapshot) {
                                                snapshot.children.forEach { idComandaIdProducto ->
                                                    val queryFinal = idComandaIdProducto.key.let {
                                                        idComandaQuery.child(it!!)
                                                    }

                                                    queryFinal.addListenerForSingleValueEvent(object :
                                                        ValueEventListener {
                                                        override fun onDataChange(snapshot: DataSnapshot) {
                                                            snapshot.ref.child("idProducto")
                                                                .removeValue()
                                                            snapshot.ref.child("nombreProducto")
                                                                .removeValue()
                                                            snapshot.ref.child("costeProducto")
                                                                .removeValue()
                                                            snapshot.ref.child("descripcionProducto")
                                                                .removeValue()
                                                            snapshot.ref.child("imagenProducto")
                                                                .removeValue()
                                                        }

                                                        override fun onCancelled(error: DatabaseError) {
                                                            TODO("Not yet implemented")
                                                        }
                                                    })
                                                }

                                            }

                                            override fun onCancelled(error: DatabaseError) {
                                                TODO("Not yet implemented")
                                            }

                                        })
                                    }
                                }

                                override fun onCancelled(error: DatabaseError) {
                                    TODO("Not yet implemented")
                                }
                            })
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }


            })
    }

    private fun finalizarComanda() {

        comprovarComanda = 1

        dbReference.orderByKey().equalTo(user.uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                @SuppressLint("SimpleDateFormat")
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { idUser ->
                        Log.w("idUser", idUser.toString())
                        val uidCliente =
                            idUser.key.let { dbReference.child(it!!) }
                        Log.w("idProducto", uidCliente.toString())

                        val comandaFinal = uidCliente.child("comandas").push()

                        val sdf = SimpleDateFormat("dd/M/yyyy")
                        val fechaActual = sdf.format(Date())

                        comandaFinal.child("coste").setValue(bindingCarrito.tfPreu.text.toString())
                        comandaFinal.child("estado").setValue("Revisió")
                        comandaFinal.child("fecha").setValue(fechaActual)

                        uidCliente.child("comandaCache")
                            .addValueEventListener(object : ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    Log.w("snapTest", snapshot.ref.toString())
                                    snapshot.children.forEach { test ->
                                        val idPrincipalProducto = test.key.toString()
                                        Log.w("snapComandaTemp", test.key.toString())

                                        val referenciaIdProductoPrincipal = test.ref
                                        Log.w("snapComandaTemp", test.ref.toString())

                                        referenciaIdProductoPrincipal.addListenerForSingleValueEvent(
                                            object :
                                                ValueEventListener {
                                                override fun onDataChange(snapshot: DataSnapshot) {
                                                    snapshot.children.forEach { refIdProd ->
                                                        val idProducto = refIdProd.key.toString()
                                                        Log.w("testSnap2", refIdProd.key.toString())

                                                        val referenciaIdProducto = refIdProd.ref
                                                        Log.w("refIdProd", refIdProd.ref.toString())

                                                        referenciaIdProducto.addValueEventListener(
                                                            object : ValueEventListener {
                                                                override fun onDataChange(snapshot: DataSnapshot) {
                                                                    Log.w(
                                                                        "testNombre",
                                                                        snapshot.toString()
                                                                    )

                                                                    val nombre =
                                                                        snapshot.child("nombreProducto").value.toString()

                                                                    val coste =
                                                                        snapshot.child("costeProducto").value.toString()
                                                                    val descripcion =
                                                                        snapshot.child("descripcionProducto").value.toString()
                                                                    val imagen =
                                                                        snapshot.child("imagenProducto").value.toString()

                                                                    val referenciaFinal =
                                                                        comandaFinal.child("producto")
                                                                            .child(idPrincipalProducto)
                                                                            .child(idProducto)

                                                                    referenciaFinal.child("nombre")
                                                                        .setValue(nombre)

                                                                    referenciaFinal.child("coste")
                                                                        .setValue(coste)

                                                                    referenciaFinal.child("descripcion")
                                                                        .setValue(descripcion)

                                                                    referenciaFinal.child("imagen")
                                                                        .setValue(imagen)

                                                                }

                                                                override fun onCancelled(error: DatabaseError) {
                                                                    TODO("Not yet implemented")
                                                                }

                                                            })
                                                    }
                                                }

                                                override fun onCancelled(error: DatabaseError) {
                                                    TODO("Not yet implemented")
                                                }

                                            })

                                    }

                                }

                                override fun onCancelled(error: DatabaseError) {
                                    TODO("Not yet implemented")
                                }

                            })

                        bindingCarrito.tfPreu.text = ""
                        costeTotal = 0
                        findNavController().navigate(R.id.action_to_pantallaInicio)


                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            })
    }

    private fun showAlert() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle(getString(R.string.comandaRealitzada))
        builder.setMessage(getString(R.string.comandaRealitzada2))
        builder.setPositiveButton(
            getString(R.string.infoAcceptar)
        ) { _, _ -> eliminarComandaTemp() }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }


}