package cat.copernic.ericbeltran.bdserveis.tienda

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentNuevoProductoBinding
import cat.copernic.ericbeltran.bdserveis.snack
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.StorageTask
import com.google.firebase.storage.UploadTask

class NuevoProductoFragment : Fragment() {

    private lateinit var bindingNuevoProducto: FragmentNuevoProductoBinding

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var tiendaReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private val GALLERY_PICKUP_CODE: Int = 123
    private var imageUri: Uri? = null
    private var storageRef: StorageReference? = null
    private var glbUrl = ""

    private var disponible = 0
    private var noDisponible = 0
    private var categoriaProducte = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentNuevoProductoBinding.inflate(inflater, container, false)
        bindingNuevoProducto = binding
        bindingNuevoProducto.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")
        tiendaReference = FirebaseDatabase.getInstance().reference.child("TENDA/CATEGORIA")
        storageRef = FirebaseStorage.getInstance().reference.child("TIENDA")

        bindingNuevoProducto.btnAnadirProductoTienda.setOnClickListener {
            nuevoProducto()
        }

        bindingNuevoProducto.btnImagenProdcuto.setOnClickListener {
            pickImage()
        }

        seleccionarCategoria()
        seleccionarDisponibilidad()

        return binding.root
    }

    private fun seleccionarCategoria() {
        val catAlarmas = bindingNuevoProducto.categoriaAlarmes
        val catExtint = bindingNuevoProducto.categoriaExtintors
        val catCamaras = bindingNuevoProducto.categoriaCameras

        catAlarmas.setOnClickListener {
            categoriaProducte = "ALARMAS"

            catAlarmas.setBackgroundColor(Color.YELLOW)
            catExtint.setBackgroundColor(Color.TRANSPARENT)
            catCamaras.setBackgroundColor(Color.TRANSPARENT)
        }
        catExtint.setOnClickListener {
            categoriaProducte = "EXTINTORES"

            catAlarmas.setBackgroundColor(Color.TRANSPARENT)
            catExtint.setBackgroundColor(Color.YELLOW)
            catCamaras.setBackgroundColor(Color.TRANSPARENT)
        }
        catCamaras.setOnClickListener {
            categoriaProducte = "CAMARAS"

            catAlarmas.setBackgroundColor(Color.TRANSPARENT)
            catExtint.setBackgroundColor(Color.TRANSPARENT)
            catCamaras.setBackgroundColor(Color.YELLOW)
        }
    }

    private fun seleccionarDisponibilidad() {
        val dispo = bindingNuevoProducto.txtDisponible
        val noDispo = bindingNuevoProducto.txtNoDisponible

        dispo.setOnClickListener {
            dispo.setBackgroundColor(Color.GREEN)
            disponible = 1
            noDisponible = 0
            noDispo.setBackgroundColor(Color.TRANSPARENT)
        }
        noDispo.setOnClickListener {
            dispo.setBackgroundColor(Color.TRANSPARENT)
            noDisponible = 1
            disponible = 0
            noDispo.setBackgroundColor(Color.RED)
        }
    }

    private fun nuevoProducto() {
        val nombreProducto = bindingNuevoProducto.tfNombreProducto.text.toString()
        val descripcionProducto = bindingNuevoProducto.tfDescripcionProducto.text.toString()
        val costeProducto = bindingNuevoProducto.tfCosteProducto.text.toString()
        val imagen = glbUrl

        if (categoriaProducte != "") {
            if (nombreProducto.isNotEmpty() || descripcionProducto.isNotEmpty() || costeProducto.isNotEmpty()) {
                if (disponible == 0 && noDisponible != 0 || disponible != 0 && noDisponible == 0) {
                    tiendaReference.child(categoriaProducte)
                        .addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(snapshot: DataSnapshot) {
                                Log.w("snapshottt", snapshot.toString())
                                val idProducto = snapshot.ref.push()
                                Log.w("idProducto", idProducto.toString())

                                idProducto.child("nombre").setValue(nombreProducto)
                                idProducto.child("descripcion").setValue(descripcionProducto)
                                idProducto.child("coste").setValue(costeProducto)
                                idProducto.child("imagen/imagen1").setValue(imagen)

                                val dispo = "Disponible"
                                val noDispo = "No disponible"

                                if (disponible == 1 || noDisponible == 0) {
                                    idProducto.child("disponibilidad").setValue(dispo)
                                } else if (disponible == 0 || noDisponible == 1) {
                                    idProducto.child("disponibilidad").setValue(noDispo)
                                }
                                requireView().snack(getString(R.string.producteAfegit))
                                findNavController().navigate(R.id.action_to_tendaFragment)

                            }

                            override fun onCancelled(error: DatabaseError) {
                                TODO("Not yet implemented")
                            }

                        })
                } else {
                    requireView().snack(getString(R.string.editarTendaDisponibilitat))
                }
            } else {
                requireView().snack(getString(R.string.editarTendaDadesBlanc))
            }
        } else {
            requireView().snack(getString(R.string.editarTendaCategoria))
        }
    }

    private fun pickImage(){
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent, GALLERY_PICKUP_CODE)
    }

    private fun uploadedImageToDatabase() {
        val progressBar = ProgressDialog(context)
        progressBar.show()

        if(imageUri!=null){
            var fileRef = storageRef!!.child(System.currentTimeMillis().toString() + ".jpg")

            var uploadTask: StorageTask<*>
            uploadTask = fileRef.putFile(imageUri!!)

            uploadTask.continueWithTask(Continuation <UploadTask.TaskSnapshot, Task<Uri>> { task ->
                if(!task.isSuccessful){
                    task.exception?.let {
                        throw it
                    }
                }
                return@Continuation fileRef.downloadUrl
            }).addOnCompleteListener{ task ->
                if (task.isSuccessful){
                    imageUri = task.result
                    glbUrl = imageUri.toString()

                    progressBar.dismiss()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GALLERY_PICKUP_CODE && resultCode == Activity.RESULT_OK && data!!.data != null){
            imageUri = data.data
            uploadedImageToDatabase()
        }

    }
}