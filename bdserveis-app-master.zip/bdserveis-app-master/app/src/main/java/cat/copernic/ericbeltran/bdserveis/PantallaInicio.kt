package cat.copernic.ericbeltran.bdserveis

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentPantallaInicioBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class PantallaInicio : Fragment(), View.OnTouchListener {

    private lateinit var bindingInicio: FragmentPantallaInicioBinding
    private var mIgnoreCurrentGesture = false

    //Datos Firebase
    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val binding = FragmentPantallaInicioBinding.inflate(inflater, container, false)
        bindingInicio = binding

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")

        this.bindingInicio.igBtnComandes.setOnClickListener {
            findNavController().navigate(R.id.action_to_comandesFragment)
        }

        this.bindingInicio.txtBtnComandas.setOnClickListener {
            findNavController().navigate(R.id.action_to_comandesFragment)
        }


        this.bindingInicio.igBtnInfo.setOnClickListener {
            findNavController().navigate(R.id.action_to_informacioFragment)
        }

        this.bindingInicio.txtBtnInfo.setOnClickListener {
            findNavController().navigate(R.id.action_to_informacioFragment)
        }


        this.bindingInicio.igBtnPerfil.setOnClickListener {
            findNavController().navigate(R.id.action_to_perfilFragment)
        }

        this.bindingInicio.txtBtnPerfil.setOnClickListener {
            findNavController().navigate(R.id.action_to_perfilFragment)
        }


        this.bindingInicio.igBtnTenda.setOnClickListener {
            findNavController().navigate(R.id.action_to_tendaFragment)
        }

        this.bindingInicio.txtBtnTienda.setOnClickListener {
            findNavController().navigate(R.id.action_to_tendaFragment)
        }


        this.bindingInicio.igBtnClientes.setOnClickListener {
            findNavController().navigate(R.id.action_to_clientesFragment)
        }

        this.bindingInicio.txtBtnClientes.setOnClickListener {
            findNavController().navigate(R.id.action_to_clientesFragment)
        }


        this.bindingInicio.btnAjustes.setOnClickListener {
            findNavController().navigate(R.id.action_to_ajustesFragment)
        }

        //Reducir el radio clicable de los botones
        val comandes: View = bindingInicio.igBtnComandes
        comandes.setOnTouchListener(PantallaInicio())
        val txtComandas: View = bindingInicio.txtBtnComandas
        txtComandas.setOnTouchListener(PantallaInicio())

        val info: View = bindingInicio.igBtnInfo
        info.setOnTouchListener(PantallaInicio())
        val txtInfo: View = bindingInicio.txtBtnInfo
        txtInfo.setOnTouchListener(PantallaInicio())

        val tenda: View = bindingInicio.igBtnTenda
        tenda.setOnTouchListener(PantallaInicio())
        val txtTienda: View = bindingInicio.txtBtnTienda
        txtTienda.setOnTouchListener(PantallaInicio())

        val perfil: View = bindingInicio.igBtnPerfil
        perfil.setOnTouchListener(PantallaInicio())
        val txtPerfil: View = bindingInicio.txtBtnPerfil
        txtPerfil.setOnTouchListener(PantallaInicio())

        val clientes: View = bindingInicio.igBtnClientes
        clientes.setOnTouchListener(PantallaInicio())
        val txtClientes: View = bindingInicio.txtBtnClientes
        txtClientes.setOnTouchListener(PantallaInicio())

        //Establecer nombre del cliente debajo de la pantalla
        nombreCliente()


        // Inflate the layout for this fragment
        return binding.root

    }

    //Metodo para visualizar los botones dependiendo del tipo de usuario CLIENTE/ADMIN
    override fun onStart() {
        val adminAuth: FirebaseAuth = FirebaseAuth.getInstance()
        val admin = adminAuth.currentUser!!

        adminReference.orderByKey().limitToFirst(1).equalTo(admin.uid)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { user ->
                            bindingInicio.igBtnClientes.setVisibility(VISIBLE)
                            bindingInicio.txtBtnClientes.setVisibility(VISIBLE)
                            bindingInicio.igBtnPerfil.setVisibility(GONE)
                            bindingInicio.txtBtnPerfil.setVisibility(GONE)

                            val nombre = user.child("nomComplert").value.toString()
                            bindingInicio.txtNombreCliente.text = (getString(R.string.benvingut) + nombre)
                        }
                    } else {
                        bindingInicio.igBtnClientes.setVisibility(GONE)
                        bindingInicio.txtBtnClientes.setVisibility(GONE)
                        bindingInicio.igBtnPerfil.setVisibility(VISIBLE)
                        bindingInicio.txtBtnPerfil.setVisibility(VISIBLE)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            })

        super.onStart()
    }

    //Funcion para cargar nombre del cliente
    private fun nombreCliente() {
        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { user ->
                            val nombre = user.child("nomComplert").value.toString()
                            Log.w("nombrePersona", nombre)

                            bindingInicio.txtNombreCliente.text =
                                (getString(R.string.benvingut) + nombre)
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("Cancelar", error.toString())
                }

            })
    }

    private fun TouchAreaFilter() {
        mIgnoreCurrentGesture = false
    }

    private fun isInTouchArea(view: View, x: Float, y: Float): Boolean {
        val w = view.width
        val h = view.height
        if (w <= 0 || h <= 0) return false
        val xhat = 2 * x / w - 1
        val yhat = 2 * y / h - 1
        return xhat * xhat + yhat * yhat <= 1
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouch(view: View?, event: MotionEvent): Boolean {
        val action = event.actionMasked
        if (action == MotionEvent.ACTION_DOWN) {
            mIgnoreCurrentGesture = !view.let { this.isInTouchArea(it!!, event.x, event.y) }
            return mIgnoreCurrentGesture
        }
        val ignoreCurrentGesture: Boolean = mIgnoreCurrentGesture
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) mIgnoreCurrentGesture =
            false
        return ignoreCurrentGesture
    }

}