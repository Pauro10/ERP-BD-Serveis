package cat.copernic.ericbeltran.bdserveis.cliente

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.adapters.InfoComandasAdapter
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInfoComandaBinding
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class InfoComanda : Fragment() {

    private lateinit var bindingInfoComanda: FragmentInfoComandaBinding

    private lateinit var infoComandasAdapter: InfoComandasAdapter

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private val args by navArgs<InfoComandaArgs>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentInfoComandaBinding.inflate(inflater, container, false)
        bindingInfoComanda = binding

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")

        this.bindingInfoComanda.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        //bindingInfoComanda.tfNom.setText(args.currentComanda.NomComplert)
        //bindingInfoComanda.tfTelefon.setText(args.currentComanda.numeroTelefon)
        //bindingInfoComanda.tfCorreu.setText(args.currentComanda.correu)
        bindingInfoComanda.tfPreu.setText(args.currentComanda.comandas.coste)
        bindingInfoComanda.textData.text = args.currentComanda.comandas.fecha

        if (args.currentComanda.comandas.estado == "Pendent") {
            bindingInfoComanda.estatPendent.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.rojoCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComanda.txtPendent.visibility = View.VISIBLE
            bindingInfoComanda.button.isFocusable = true
            bindingInfoComanda.button.setBackgroundColor(
                ContextCompat.getColor(requireContext(), R.color.black)
            )
        } else if (args.currentComanda.comandas.estado == "Revisió") {
            bindingInfoComanda.estatRevisio.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.amarilloCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComanda.txtRevisio.visibility = View.VISIBLE
            bindingInfoComanda.button.isFocusable = false
        } else if (args.currentComanda.comandas.estado == "Acceptat") {
            bindingInfoComanda.estatProces.setColorFilter(
                ContextCompat.getColor(requireContext(), R.color.verdeCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            bindingInfoComanda.txtProces.visibility = View.VISIBLE
            bindingInfoComanda.button.isFocusable = false
        }

        initComandesRecycler()

        return binding.root
    }

    private fun initComandesRecycler() {
        this.bindingInfoComanda.rvProductes.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        this.infoComandasAdapter = InfoComandasAdapter(requireContext())
        this.bindingInfoComanda.rvProductes.adapter = this.infoComandasAdapter

        return observeData()
    }

    fun fetchGestionComandas(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        getDatosComandaProductos().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeData() {
        fetchGestionComandas().observe(viewLifecycleOwner, Observer {
            infoComandasAdapter.setListData(it)
            infoComandasAdapter.notifyDataSetChanged()
        })
    }

    private fun getDatosComandaProductos(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        val listData = mutableListOf<Usuari>()
        val uidCliente = args.currentComanda.uidCliente
        val idComanda = args.currentComanda.comandas.idComanda
        Log.w("idComanda", idComanda)

        dbReference.orderByKey().limitToFirst(1).equalTo(uidCliente)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { info ->

                            val comandaQuery =
                                info.key.let { dbReference.child(it!!).child("comandas") }
                            comandaQuery.orderByKey().equalTo(idComanda)
                                .addListenerForSingleValueEvent(object : ValueEventListener {
                                    override fun onDataChange(snapshot: DataSnapshot) {
                                        snapshot.children.forEach { idComanda ->
                                            val idComandaQuery = idComanda.key.let {
                                                comandaQuery.child(it!!).child("producto")
                                            }
                                            Log.w("idComandaQuery", idComandaQuery.toString())
                                            idComandaQuery.orderByKey()
                                                .addListenerForSingleValueEvent(object :
                                                    ValueEventListener {
                                                    override fun onDataChange(snapshot: DataSnapshot) {
                                                        snapshot.children.forEach { idProducto ->
                                                            val idProductoQuery =
                                                                idProducto.key.let {
                                                                    idComandaQuery.child(it!!)
                                                                }
                                                            Log.w(
                                                                "idProductoQuery",
                                                                idProductoQuery.toString()
                                                            )
                                                            idProductoQuery.addValueEventListener(
                                                                object : ValueEventListener {
                                                                    override fun onDataChange(
                                                                        snapshot: DataSnapshot
                                                                    ) {
                                                                        snapshot.children.forEach { idProductoBuena ->
                                                                            val idFinal =
                                                                                idProductoBuena.key.let {
                                                                                    idProductoQuery.child(
                                                                                        it!!
                                                                                    )
                                                                                }
                                                                            idFinal.addValueEventListener(
                                                                                object :
                                                                                    ValueEventListener {
                                                                                    override fun onDataChange(
                                                                                        snapshot: DataSnapshot
                                                                                    ) {
                                                                                        val nombreProducto =
                                                                                            snapshot.child(
                                                                                                "nombre"
                                                                                            ).value.toString()
                                                                                        val costeProducto =
                                                                                            snapshot.child(
                                                                                                "coste"
                                                                                            ).value.toString()
                                                                                        val imagen = snapshot.child("imagen").value.toString()

                                                                                        val listaProductos =
                                                                                            Usuari(
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                "",
                                                                                                Comandas(
                                                                                                    "",
                                                                                                    "",
                                                                                                    "",
                                                                                                    "",
                                                                                                    Producto(
                                                                                                        "",
                                                                                                        nombreProducto,
                                                                                                        costeProducto,
                                                                                                        "",
                                                                                                        "",
                                                                                                        imagen
                                                                                                    )
                                                                                                )
                                                                                            )

                                                                                        listData.add(
                                                                                            listaProductos
                                                                                        )
                                                                                        mutableData.value =
                                                                                            listData
                                                                                    }

                                                                                    override fun onCancelled(
                                                                                        error: DatabaseError
                                                                                    ) {
                                                                                        TODO("Not yet implemented")
                                                                                    }

                                                                                })
                                                                        }
                                                                    }

                                                                    override fun onCancelled(error: DatabaseError) {
                                                                        TODO("Not yet implemented")
                                                                    }

                                                                })
                                                        }
                                                    }

                                                    override fun onCancelled(error: DatabaseError) {
                                                        TODO("Not yet implemented")
                                                    }

                                                })
                                        }
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        TODO("Not yet implemented")
                                    }
                                })
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }


            })


        return mutableData
    }

}