package cat.copernic.ericbeltran.bdserveis.cliente

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentRecuperarPasswordBinding
import cat.copernic.ericbeltran.bdserveis.isValidEmail
import cat.copernic.ericbeltran.bdserveis.snack
import com.google.firebase.auth.FirebaseAuth

class RecuperarPasswordFragment : DialogFragment() {

    private lateinit var bindingRecuperarPassword: FragmentRecuperarPasswordBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding = FragmentRecuperarPasswordBinding.inflate(inflater, container, false)
        bindingRecuperarPassword = binding

        bindingRecuperarPassword.btnEnviar.setOnClickListener {
            cambiarContraseña()
            dismiss()
        }


        return binding.root
    }


    private fun cambiarContraseña() {
        val email = bindingRecuperarPassword.tfMail.getText().toString()
        if (isValidEmail(email)) {
            FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        showAlert()
                        //view?.snack("Correu enviat correctament!")
                    } else {
                        view?.snack(getString(R.string.errorEnviarCorreu))
                    }
                }
        } else {
            view?.snack(getString(R.string.formatEmailInvalid))
        }
    }

    private fun showAlert() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle(getString(R.string.correuEnviatCorrecte))
        builder.setMessage(getString(R.string.revisaCorreu))
        builder.setPositiveButton(getString(R.string.infoAcceptar), null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

}