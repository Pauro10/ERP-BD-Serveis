package cat.copernic.ericbeltran.bdserveis.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.cliente.ComandesFragmentDirections
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import java.util.*

class ComandasAdapter(private val context: Context) :
    RecyclerView.Adapter<ComandasAdapter.ViewHolder>() {

    private var dataListComanda = mutableListOf<Usuari>()

    private lateinit var auth: FirebaseAuth
    private lateinit var user: FirebaseUser

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.diseno_comandas, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        val currentItemComanda = dataListComanda[position]
        val estadoComandaCheck = holder.itemView.findViewById<TextView>(R.id.txtEstadoComanda)
        holder.itemView.findViewById<TextView>(R.id.txtFechaComanda).text =
            currentItemComanda.comandas.fecha
        estadoComandaCheck.text =
            ("COMANDA EN " + currentItemComanda.comandas.estado.toUpperCase(Locale.ROOT))
        holder.itemView.findViewById<TextView>(R.id.costeComanda).text =
            ("COST TOTAL: " + currentItemComanda.comandas.coste + " €")


        if (estadoComandaCheck.text == "COMANDA EN PENDENT") {
            //Rojo
            holder.itemView.findViewById<ImageView>(R.id.estatComandaImg).setColorFilter(
                ContextCompat.getColor(context, R.color.rojoCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            estadoComandaCheck.text = "COMANDA PENDENT DE PAGAMENT"
        } else if (estadoComandaCheck.text == "COMANDA EN REVISIÓ") {
            //Amarillo
            holder.itemView.findViewById<ImageView>(R.id.estatComandaImg).setColorFilter(
                ContextCompat.getColor(context, R.color.amarilloCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
        } else if (estadoComandaCheck.text == "COMANDA EN ACCEPTAT") {
            //Verde
            holder.itemView.findViewById<ImageView>(R.id.estatComandaImg).setColorFilter(
                ContextCompat.getColor(context, R.color.verdeCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            estadoComandaCheck.text = "COMANDA ACCEPTADA"
        }

        if (user.uid == "my3s7XE0g7UsaSInM5AW9d2Di8u1") {

            holder.itemView.findViewById<CardView>(R.id.cardViewComandas).setOnClickListener {
                val action = ComandesFragmentDirections.actionToInfoComandaAdmin(currentItemComanda)
                holder.itemView.findNavController().navigate(action)
            }

        } else {

            holder.itemView.findViewById<CardView>(R.id.cardViewComandas).setOnClickListener {
                val action = ComandesFragmentDirections.actionToInfoComanda(currentItemComanda)
                holder.itemView.findNavController().navigate(action)
            }

        }

    }

    override fun getItemCount(): Int {
        return dataListComanda.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    fun setListData(data: MutableList<Usuari>) {
        dataListComanda = data
        notifyDataSetChanged()
    }

}