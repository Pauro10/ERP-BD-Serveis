package cat.copernic.ericbeltran.bdserveis.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.squareup.picasso.Picasso

class InfoComandasAdapter(private val context: Context) :
    RecyclerView.Adapter<InfoComandasAdapter.ViewHolder>() {

    private var dataListProductos = mutableListOf<Usuari>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.diseno_productos, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItemProducto = dataListProductos[position]
        holder.itemView.findViewById<TextView>(R.id.txtNombreProducto).text =
            currentItemProducto.comandas.producto.nombre
        holder.itemView.findViewById<TextView>(R.id.txtPrecioProducto).text =
            (currentItemProducto.comandas.producto.coste + " €")
        val imagen = holder.itemView.findViewById<ImageView>(R.id.imgProductoDiseno)
        Picasso.get().load(currentItemProducto.comandas.producto.imagenProducto).into(imagen)
    }

    override fun getItemCount(): Int {
        return dataListProductos.size
    }

    fun setListData(data: MutableList<Usuari>) {
        dataListProductos = data
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}