package cat.copernic.ericbeltran.bdserveis.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.admin.ClientesFragmentDirections
import cat.copernic.ericbeltran.bdserveis.models.Usuari

class ClientesAdapter(private val context: Context) :
    RecyclerView.Adapter<ClientesAdapter.ViewHolder>() {

    private var dataListClient = mutableListOf<Usuari>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.diseno_clientes, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItemClient = dataListClient[position]
        holder.itemView.findViewById<TextView>(R.id.txtNombreCliente).text =
            currentItemClient.NomComplert
        holder.itemView.findViewById<TextView>(R.id.txtDniCliente).text = currentItemClient.nif

        holder.itemView.findViewById<CardView>(R.id.cardViewComandas).setOnClickListener {
            val action = ClientesFragmentDirections.actionToInfoClient(currentItemClient)
            holder.itemView.findNavController().navigate(action)
        }

    }

    override fun getItemCount(): Int {
        return dataListClient.size
    }

    fun setListData(data: MutableList<Usuari>) {
        dataListClient = data
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

}