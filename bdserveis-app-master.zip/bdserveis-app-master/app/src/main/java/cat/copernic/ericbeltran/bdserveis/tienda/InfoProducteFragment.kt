package cat.copernic.ericbeltran.bdserveis.tienda

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInfoProducteBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import com.squareup.picasso.Picasso

class InfoProducteFragment : DialogFragment() {

    private lateinit var bindingInfoProducte: FragmentInfoProducteBinding

    private val args by navArgs<InfoProducteFragmentArgs>()

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var tiendaReference: DatabaseReference
    private lateinit var auth: FirebaseAuth


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentInfoProducteBinding.inflate(inflater, container, false)
        bindingInfoProducte = binding

        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")
        tiendaReference = FirebaseDatabase.getInstance().reference.child("TENDA/CATEGORIA")

        bindingInfoProducte.nombreAlarma.setText(args.currentProducto.nombre)
        bindingInfoProducte.txtDescripcionProducto.setText(args.currentProducto.descripcion)
        bindingInfoProducte.txtPrecioProducto.setText((args.currentProducto.coste + " €"))
        Picasso.get().load(args.currentProducto.imagenProducto)
            .into(bindingInfoProducte.imgProducto)

        bindingInfoProducte.btnAnadirProducto.setOnClickListener {
            anadirProducto()
            findNavController().navigate(R.id.action_to_tendaFragment)
            showAlert()
        }

        return binding.root
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun anadirProducto() {
        val idProductoTienda = args.currentProducto.idProducto
        val nombreProducto = args.currentProducto.nombre
        val precioProducto = args.currentProducto.coste
        val descripcionProducto = args.currentProducto.descripcion
        val imagenProducto = args.currentProducto.imagenProducto

        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { idUser ->
                        val uidCliente =
                            idUser.key.let { dbReference.child(it!!) }.child("comandaTemp").push()
                                .child(idProductoTienda)
                        val test =
                            idUser.key.let { dbReference.child(it!!) }.child("comandaCache").push()
                                .child(idProductoTienda)

                        uidCliente.child("idProducto").setValue(idProductoTienda)
                        uidCliente.child("nombreProducto").setValue(nombreProducto)
                        uidCliente.child("costeProducto").setValue(precioProducto)
                        uidCliente.child("descripcionProducto").setValue(descripcionProducto)
                        uidCliente.child("imagenProducto").setValue(imagenProducto)

                        test.child("idProducto").setValue(idProductoTienda)
                        test.child("nombreProducto").setValue(nombreProducto)
                        test.child("costeProducto").setValue(precioProducto)
                        test.child("descripcionProducto").setValue(descripcionProducto)
                        test.child("imagenProducto").setValue(imagenProducto)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            })
    }

    private fun showAlert() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle(getString(R.string.infoProducteAfegit))
        builder.setMessage(R.string.infoProducteAfegit2)
        builder.setPositiveButton(getString(R.string.infoAcceptar), null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
}
