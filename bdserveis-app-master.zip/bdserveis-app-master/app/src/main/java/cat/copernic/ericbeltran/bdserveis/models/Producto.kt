package cat.copernic.ericbeltran.bdserveis.models

import android.os.Build
import androidx.annotation.RequiresApi
import java.io.Serializable

class Producto @RequiresApi(Build.VERSION_CODES.O) constructor(
    var idProducto: String,
    var nombre: String,
    var coste: String,
    var descripcion: String,
    var disponibilidad: String,
    var imagenProducto: String
): Serializable