package cat.copernic.ericbeltran.bdserveis.tienda

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.adapters.TiendaAlarmasAdapter
import cat.copernic.ericbeltran.bdserveis.adapters.TiendaCamerasAdapter
import cat.copernic.ericbeltran.bdserveis.adapters.TiendaExtintoresAdapter
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentTendaBinding
import cat.copernic.ericbeltran.bdserveis.models.Producto
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class TendaFragment : Fragment() {

    private lateinit var bindingTenda: FragmentTendaBinding

    private lateinit var alarmasAdapter: TiendaAlarmasAdapter
    private lateinit var extintoresAdapter: TiendaExtintoresAdapter
    private lateinit var camarasAdapter: TiendaCamerasAdapter

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var tiendaReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val binding = FragmentTendaBinding.inflate(inflater, container, false)
        bindingTenda = binding

        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")
        tiendaReference = FirebaseDatabase.getInstance().reference.child("TENDA/CATEGORIA")

        this.bindingTenda.btnAtras.setOnClickListener {
            findNavController().navigate(R.id.action_to_pantallaInicio)
        }

        bindingTenda.imgCantidad.setOnClickListener {
            findNavController().navigate(R.id.action_to_carritoFragment)
        }

        if (user.uid != "my3s7XE0g7UsaSInM5AW9d2Di8u1") {
            bindingTenda.btnEditarTienda.setVisibility(View.GONE)
            bindingTenda.imgCantidad.setVisibility(View.VISIBLE)
            bindingTenda.numCantidad.setVisibility(View.VISIBLE)
        } else if (user.uid == "my3s7XE0g7UsaSInM5AW9d2Di8u1") {
            bindingTenda.btnEditarTienda.setVisibility(View.VISIBLE)
            bindingTenda.imgCantidad.setVisibility(View.GONE)
            bindingTenda.numCantidad.setVisibility(View.GONE)
        }

        bindingTenda.btnEditarTienda.setOnClickListener {
            findNavController().navigate(R.id.action_to_nuevoProductoFragment)
        }

        alarmasRecyclerView()
        extintoresRecyclerView()
        camerasRecyclerView()

        return binding.root
    }

    override fun onResume() {
        contadorProductos()
        super.onResume()
    }

    private fun contadorProductos() {
        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { idUser ->
                        val uidCliente =
                            idUser.key.let { dbReference.child(it!!) }
                        uidCliente.child("comandaTemp").orderByKey()
                            .addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    snapshot.children.forEach { idComandaTemp ->
                                        val idComandaTemporal =
                                            idComandaTemp.key.let { uidCliente.child(it!!) }.key
                                        Log.w("idComandaTemporal", idComandaTemporal.toString())

                                        var contador =
                                            bindingTenda.numCantidad.text.toString().toInt()
                                        contador += 1
                                        bindingTenda.numCantidad.text = contador.toString()
                                    }
                                }

                                override fun onCancelled(error: DatabaseError) {
                                    TODO("Not yet implemented")
                                }
                            })
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            })
    }


    private fun alarmasRecyclerView() {
        bindingTenda.rvAlarmes.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        alarmasAdapter = TiendaAlarmasAdapter(requireContext())
        bindingTenda.rvAlarmes.adapter = alarmasAdapter

        return observeDataAlarmas()
    }

    fun fetchAlarmasTienda(): LiveData<MutableList<Producto>> {
        val mutableData = MutableLiveData<MutableList<Producto>>()
        getAlarmas().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeDataAlarmas() {
        fetchAlarmasTienda().observe(viewLifecycleOwner, Observer {
            alarmasAdapter.setListData(it)
            alarmasAdapter.notifyDataSetChanged()
        })
    }

    private fun getAlarmas(): LiveData<MutableList<Producto>> {
        val mutableData = MutableLiveData<MutableList<Producto>>()
        val listData = mutableListOf<Producto>()
        val referenciaAlarmas = tiendaReference.child("ALARMAS")

        referenciaAlarmas.orderByKey()
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { alarma ->
                        val idAlarma = alarma.key.let { referenciaAlarmas.child(it!!) }.key
                        val nombre = alarma.child("nombre").value.toString()
                        val coste = alarma.child("coste").value.toString()
                        val descripcion = alarma.child("descripcion").value.toString()
                        val disponibilidad = alarma.child("disponibilidad").value.toString()
                        val imagenProducto = alarma.child("imagen/imagen1").value.toString()

                        val datosAlarmasTienda =
                            Producto(
                                idAlarma.toString(),
                                nombre,
                                coste,
                                descripcion,
                                disponibilidad,
                                imagenProducto
                            )

                        listData.add(datosAlarmasTienda)
                        mutableData.value = listData
                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })


        return mutableData
    }

    private fun extintoresRecyclerView() {
        bindingTenda.rvExtintores.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        extintoresAdapter = TiendaExtintoresAdapter(requireContext())
        bindingTenda.rvExtintores.adapter = extintoresAdapter

        return observeDataExtintors()
    }

    fun fetchExtintoresTienda(): LiveData<MutableList<Producto>> {
        val mutableData = MutableLiveData<MutableList<Producto>>()
        getExtintores().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeDataExtintors() {
        fetchExtintoresTienda().observe(viewLifecycleOwner, Observer {
            extintoresAdapter.setListData(it)
            extintoresAdapter.notifyDataSetChanged()
        })
    }

    private fun getExtintores(): LiveData<MutableList<Producto>> {
        val mutableData = MutableLiveData<MutableList<Producto>>()
        val listData = mutableListOf<Producto>()
        val referenciaExtintores = tiendaReference.child("EXTINTORES")

        referenciaExtintores.orderByKey()
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { extintor ->
                        val idExtintor = extintor.key.let { referenciaExtintores.child(it!!) }.key
                        val nombre = extintor.child("nombre").value.toString()
                        val coste = extintor.child("coste").value.toString()
                        val descripcion = extintor.child("descripcion").value.toString()
                        val disponibilidad = extintor.child("disponibilidad").value.toString()
                        val imagenProducto = extintor.child("imagen/imagen1").value.toString()

                        val datosExtintoresTienda =
                            Producto(
                                idExtintor.toString(),
                                nombre,
                                coste,
                                descripcion,
                                disponibilidad,
                                imagenProducto
                            )

                        listData.add(datosExtintoresTienda)
                        mutableData.value = listData
                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })
        return mutableData
    }

    private fun camerasRecyclerView() {
        bindingTenda.rvCamaras.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        camarasAdapter = TiendaCamerasAdapter(requireContext())
        bindingTenda.rvCamaras.adapter = camarasAdapter

        return observeDataCamaras()
    }

    fun fetchCamarasTienda(): LiveData<MutableList<Producto>> {
        val mutableData = MutableLiveData<MutableList<Producto>>()
        getCamaras().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeDataCamaras() {
        fetchCamarasTienda().observe(viewLifecycleOwner, Observer {
            camarasAdapter.setListData(it)
            camarasAdapter.notifyDataSetChanged()
        })
    }

    private fun getCamaras(): LiveData<MutableList<Producto>> {
        val mutableData = MutableLiveData<MutableList<Producto>>()
        val listData = mutableListOf<Producto>()
        val referenciaCamaras = tiendaReference.child("CAMARAS")

        referenciaCamaras.orderByKey()
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { camara ->
                        val idCamara = camara.key.let { referenciaCamaras.child(it!!) }.key
                        val nombre = camara.child("nombre").value.toString()
                        val coste = camara.child("coste").value.toString()
                        val descripcion = camara.child("descripcion").value.toString()
                        val disponibilidad = camara.child("disponibilidad").value.toString()
                        val imagenProducto = camara.child("imagen/imagen1").value.toString()

                        val datosCamarasTienda =
                            Producto(
                                idCamara.toString(),
                                nombre,
                                coste,
                                descripcion,
                                disponibilidad,
                                imagenProducto
                            )

                        listData.add(datosCamarasTienda)
                        mutableData.value = listData
                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })
        return mutableData
    }

}