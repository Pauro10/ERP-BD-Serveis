package cat.copernic.ericbeltran.bdserveis

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import cat.copernic.ericbeltran.bdserveis.registro_login.PantallaLogin

class SplashScreen : AppCompatActivity() {

    private val SPLASH_TIMER: Long = 1500

    // Variables
    private lateinit var backgroundImage: ImageView
    private lateinit var poweredByLine: TextView

    // Animations
    private lateinit var sideAnim : Animation
    private lateinit var bottomAnim : Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fullScreenMode()

        setContentView(R.layout.activity_splash_screen)

        backgroundImage = findViewById(R.id.logosplash)
        poweredByLine = findViewById(R.id.txtsplash)

        // Animations
        sideAnim = AnimationUtils.loadAnimation(this, R.anim.side_anim)
        bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_anim)

        backgroundImage.animation = sideAnim
        poweredByLine.animation = bottomAnim


        Handler().postDelayed({
            val intent: Intent
            if (getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).getBoolean("rememberOption", false)){
                intent = Intent(applicationContext, PantallaInicio::class.java)
            } else {
                intent = Intent(applicationContext, PantallaLogin::class.java)
            }
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            finish()
        }, SPLASH_TIMER)
    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }
}