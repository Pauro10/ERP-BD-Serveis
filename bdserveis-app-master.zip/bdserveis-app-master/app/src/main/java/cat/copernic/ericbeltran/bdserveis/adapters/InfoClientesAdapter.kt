package cat.copernic.ericbeltran.bdserveis.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import java.util.*

class InfoClientesAdapter(private val context: Context) :
    RecyclerView.Adapter<InfoClientesAdapter.ViewHolder>() {

    private var dataListComandas = mutableListOf<Usuari>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.diseno_comandas, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItemComanda = dataListComandas[position]
        val estadoComandaCheck = holder.itemView.findViewById<TextView>(R.id.txtEstadoComanda)
        holder.itemView.findViewById<TextView>(R.id.txtFechaComanda).text =
            currentItemComanda.comandas.fecha
        estadoComandaCheck.text =
            ("COMANDA EN " + currentItemComanda.comandas.estado.toUpperCase(Locale.ROOT))
        holder.itemView.findViewById<TextView>(R.id.costeComanda).text =
            currentItemComanda.comandas.coste

        if (estadoComandaCheck.text == "COMANDA EN PENDENT") {
            //Rojo
            holder.itemView.findViewById<ImageView>(R.id.estatComandaImg).setColorFilter(
                ContextCompat.getColor(context, R.color.rojoCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            estadoComandaCheck.text = "COMANDA PENDENT DE PAGAMENT"
        } else if (estadoComandaCheck.text == "COMANDA EN REVISIÓ") {
            //Amarillo
            holder.itemView.findViewById<ImageView>(R.id.estatComandaImg).setColorFilter(
                ContextCompat.getColor(context, R.color.amarilloCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
        } else if (estadoComandaCheck.text == "COMANDA EN ACCEPTAT") {
            //Verde
            holder.itemView.findViewById<ImageView>(R.id.estatComandaImg).setColorFilter(
                ContextCompat.getColor(context, R.color.verdeCheck),
                android.graphics.PorterDuff.Mode.SRC_IN
            )
            estadoComandaCheck.text = "COMANDA ACCEPTADA"
        }

    }

    override fun getItemCount(): Int {
        return dataListComandas.size
    }

    fun setListData(data: MutableList<Usuari>) {
        dataListComandas = data
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}