package cat.copernic.ericbeltran.bdserveis.informacion

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInformacio4Binding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class InformacioFragment4 : Fragment() {

    private lateinit var bindingInfo4: FragmentInformacio4Binding
    private lateinit var mMap: GoogleMap
    private lateinit var latUpdate: String
    private lateinit var longUpdate: String

    private val callback = OnMapReadyCallback { googleMap ->

        val BDServeis = LatLng(41.55824075971581, 1.9961065402465694)
        val zoomLevel = 15f
        googleMap.addMarker(MarkerOptions().position(BDServeis).title("BD Serveis Oficina"))
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(BDServeis, zoomLevel))

        googleMap.getUiSettings().setZoomControlsEnabled(true)

        googleMap.setOnMapLongClickListener { m ->
            googleMap.clear()
            googleMap.addMarker(
                MarkerOptions()
                    .position(m)
            )
            latUpdate = m.latitude.toString()
            longUpdate = m.longitude.toString()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding = FragmentInformacio4Binding.inflate(inflater, container, false)
        bindingInfo4 = binding


        bindingInfo4.btnIniciInfo.setOnClickListener {
            findNavController().navigate(R.id.action_to_pantallaInicio)
        }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)
    }

}