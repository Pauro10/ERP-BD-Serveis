package cat.copernic.ericbeltran.bdserveis.ajustes

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentCondicionsBinding

class CondicionsFragment : DialogFragment() {

    private lateinit var bindingCond: FragmentCondicionsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val binding = FragmentCondicionsBinding.inflate(inflater, container, false)
        bindingCond = binding

        return binding.root
    }
}