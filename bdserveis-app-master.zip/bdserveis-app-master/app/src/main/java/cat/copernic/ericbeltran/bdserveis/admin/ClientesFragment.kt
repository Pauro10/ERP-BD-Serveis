package cat.copernic.ericbeltran.bdserveis.admin

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.ericbeltran.bdserveis.adapters.ClientesAdapter
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentClientesBinding
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class ClientesFragment : Fragment() {

    private lateinit var bindingClientes: FragmentClientesBinding

    private lateinit var clientesAdapter: ClientesAdapter

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentClientesBinding.inflate(inflater, container, false)
        bindingClientes = binding

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")

        this.bindingClientes.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        //Llamamos al metodo de lectura de datos
        clientesRecyclerView()

        return binding.root
    }


    private fun clientesRecyclerView() {
        bindingClientes.rvClientes.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        clientesAdapter = ClientesAdapter(requireContext())
        bindingClientes.rvClientes.adapter = clientesAdapter

        return observeData()
    }

    fun fetchGestionClientes(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        getDatosCliente().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeData() {
        fetchGestionClientes().observe(viewLifecycleOwner, Observer {
            clientesAdapter.setListData(it)
            clientesAdapter.notifyDataSetChanged()
        })
    }

    private fun getDatosCliente(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        val listData = mutableListOf<Usuari>()

        dbReference.orderByKey().addListenerForSingleValueEvent(object : ValueEventListener {
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { cliente ->
                    val uidCliente = cliente.key.let { dbReference.child(it!!) }.key
                    Log.w("uidCliente", uidCliente.toString())
                    val nombre = cliente.child("nomComplert").value.toString()
                    Log.w("nombre", nombre)
                    val nif = cliente.child("nif").value.toString()
                    val correo = cliente.child("correu").value.toString()
                    val gender = cliente.child("gender").value.toString()
                    val nacimiento = cliente.child("dataNaixement").value.toString()
                    val countryCode = cliente.child("countryCode").value.toString()
                    val telefono = cliente.child("numeroTelefon").value.toString()


                    val datosClientes = Usuari(
                        uidCliente.toString(),
                        nombre,
                        correo,
                        gender,
                        nacimiento,
                        nif,
                        countryCode,
                        telefono,
                        Comandas(
                            "",
                            "",
                            "",
                            "",
                            Producto("", "","","","","")
                        )
                    )

                    listData.add(datosClientes)
                    mutableData.value = listData

                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
        return mutableData
    }

    private fun cargarDatos() {

    }

}