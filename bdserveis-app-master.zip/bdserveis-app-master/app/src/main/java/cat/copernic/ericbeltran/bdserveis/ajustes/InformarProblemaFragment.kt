package cat.copernic.ericbeltran.bdserveis.ajustes

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInformarProblemaBinding
import cat.copernic.ericbeltran.bdserveis.snack
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class InformarProblemaFragment : DialogFragment() {

    private lateinit var bindingInformarProblema: FragmentInformarProblemaBinding
    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private var emailCliente = ""
    private var nombreCliente = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentInformarProblemaBinding.inflate(inflater, container, false)
        bindingInformarProblema = binding

        //Current User
        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")

        bindingInformarProblema.btnEnviarComentario.setOnClickListener {
            if (bindingInformarProblema.tfInformarProblema.text.isNullOrEmpty()) {
                requireView().snack(getString(R.string.errorInformarProblema))
            } else {
                enviarEmail()
            }
        }
        return binding.root
    }

    private fun enviarEmail() {

        dbReference.orderByKey().limitToFirst(1).equalTo(user.uid)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        snapshot.children.forEach { user ->
                            val nomComplert = user.child("nomComplert").value.toString()
                            val correu = user.child("correu").value.toString()
                            emailCliente = correu
                            nombreCliente = nomComplert
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("Cancelar", error.toString())
                }

            })

        val intent = Intent(Intent.ACTION_SEND)
        val mensaje = bindingInformarProblema.tfInformarProblema.text.toString()

        intent.type = "text/html"

        intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("bdserveisapp@gmail.com"))
        intent.putExtra(Intent.EXTRA_CC, arrayOf(emailCliente))
        intent.putExtra(Intent.EXTRA_SUBJECT, arrayOf(nombreCliente))
        intent.putExtra(Intent.EXTRA_TEXT, arrayOf(mensaje))

        val chooser = Intent.createChooser(intent, getString(R.string.problemaComentari))

        startActivity(chooser)

    }

}