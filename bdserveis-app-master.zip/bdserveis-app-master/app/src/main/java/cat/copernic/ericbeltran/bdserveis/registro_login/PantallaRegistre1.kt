package cat.copernic.ericbeltran.bdserveis.registro_login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.ActivityPantallaRegistre1Binding
import cat.copernic.ericbeltran.bdserveis.email_Param
import cat.copernic.ericbeltran.bdserveis.snack

class PantallaRegistre1 : AppCompatActivity() {

    private lateinit var bindingRegistro1: ActivityPantallaRegistre1Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindingRegistro1 = DataBindingUtil.setContentView(this,
            R.layout.activity_pantalla_registre1
        )

        fullScreenMode()

        // Boto Tornar Enrrere
        this.bindingRegistro1.btnTornar.setOnClickListener {
            cambiarPantalla(it, 0)
        }

        // Next Signup Screen
        this.bindingRegistro1.btnSeguent.setOnClickListener {

            if( !comprovarCamps(it) ){
                return@setOnClickListener
            }

            // Camps Comprovats
            cambiarPantalla(it, 1)
        }

        // Pantalla Identifica't
        this.bindingRegistro1.txtIdentificar.setOnClickListener {
            cambiarPantalla(it, 2)
        }


    }

    private fun cambiarPantalla(view: View, option: Int ){

        var intent = Intent()

        when(option){
            0 -> {
                // Atrás
                intent = Intent( applicationContext, PantallaLogin::class.java )
            }
            1 -> {
                // Següent
                intent = Intent( applicationContext, PantallaRegistre2::class.java ).apply {
                    // Preparamos los datos del usuario
                    this.putExtra("EXTRA_SESSION_NOMCOMPLERT", bindingRegistro1.tfNom.text.toString() )
                    this.putExtra("EXTRA_SESSION_DNI", bindingRegistro1.tfDni.text.toString() )
                    this.putExtra("EXTRA_SESSION_CORREU", bindingRegistro1.tfMail.text.toString() )
                    this.putExtra("EXTRA_SESSION_PASSWORD", bindingRegistro1.tfContrasena.text.toString() )
                }
            }
            2 -> {
                // Login
                intent = Intent( applicationContext, PantallaLogin::class.java )
            }
        }

        startActivity(intent)
        if( option == 0 ){
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        }else{
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        finish()
    }

    private fun comprovarCamps(view: View): Boolean {

        // Validate password
        return if( this.bindingRegistro1.tfContrasena.text.toString() == "" || this.bindingRegistro1.tfContrasena.text.toString().length < 6 ) {
            view.snack(getString(R.string.passwordCaracters))
            false
        } else if( this.bindingRegistro1.tfMail.text.toString() == "" || !this.bindingRegistro1.tfMail.text.toString().contains(regex = email_Param.toRegex())) {
            view.snack(getString(R.string.correuValid))
            false
        } else if( this.bindingRegistro1.tfDni.text.toString() == "" ) {
            view.snack(getString(R.string.omplirDni))
            false
        } else if( this.bindingRegistro1.tfNom.text.toString() == "" ) {
            view.snack(getString(R.string.omplirNom))
            false
        } else{
            true
        }

    }

    private fun  fullScreenMode(){
        // Amagar actionBar i mode fullScreen
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }
}