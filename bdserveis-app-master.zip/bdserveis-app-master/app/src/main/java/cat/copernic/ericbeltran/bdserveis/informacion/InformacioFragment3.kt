package cat.copernic.ericbeltran.bdserveis.informacion

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInformacio3Binding

class InformacioFragment3 : Fragment() {


    private lateinit var bindingInfo3: FragmentInformacio3Binding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding = FragmentInformacio3Binding.inflate(inflater, container, false)
        bindingInfo3 = binding

        this.bindingInfo3.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        bindingInfo3.btnFinalitzaInfo.setOnClickListener {
            findNavController().navigate(R.id.action_to_informacioFragment4)
        }
        bindingInfo3.btnOmet3.setOnClickListener {
            findNavController().navigate(R.id.action_to_informacioFragment4)
        }

        return binding.root
    }

}