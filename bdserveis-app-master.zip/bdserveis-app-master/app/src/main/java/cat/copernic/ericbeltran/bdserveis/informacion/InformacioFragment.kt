package cat.copernic.ericbeltran.bdserveis.informacion

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInformacioBinding


class InformacioFragment : Fragment() {

    private lateinit var bindingInfo: FragmentInformacioBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val binding = FragmentInformacioBinding.inflate(inflater, container, false)
        bindingInfo = binding

        this.bindingInfo.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }
        bindingInfo.btnSeguent1.setOnClickListener {
            findNavController().navigate(R.id.action_to_informacioFragment2)
        }
        bindingInfo.btnOmet1.setOnClickListener {
            findNavController().navigate(R.id.action_to_informacioFragment4)
        }

        return binding.root
    }

}