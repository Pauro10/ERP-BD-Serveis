package cat.copernic.ericbeltran.bdserveis.admin

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import cat.copernic.ericbeltran.bdserveis.adapters.InfoClientesAdapter
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentInfoClientBinding
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

class InfoClient : Fragment() {

    private lateinit var bindingInfo: FragmentInfoClientBinding

    private lateinit var infoClientesAdapter: InfoClientesAdapter

    private val args by navArgs<InfoClientArgs>()

    //Firebase
    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentInfoClientBinding.inflate(inflater, container, false)
        bindingInfo = binding

        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")

        this.bindingInfo.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        bindingInfo.txtNombreCliente.setText(args.currentClient.NomComplert)
        bindingInfo.tfDniClient.setText(args.currentClient.nif)
        bindingInfo.tfDniClient.isFocusable = false
        bindingInfo.tfTelefonClient.setText(args.currentClient.numeroTelefon)
        bindingInfo.tfTelefonClient.isFocusable = false
        bindingInfo.tfMailClient.setText(args.currentClient.correu)
        bindingInfo.tfMailClient.isFocusable = false

        comandasClienteRecyclerView()

        Log.w("uidClienteInfo", args.currentClient.uidCliente)

        return binding.root
    }

    private fun comandasClienteRecyclerView() {
        bindingInfo.rvComandasCliente.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        infoClientesAdapter = InfoClientesAdapter(requireContext())
        bindingInfo.rvComandasCliente.adapter = infoClientesAdapter

        return observeData()
    }

    fun fetchComandasCliente(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        getComandasCliente().observeForever { datosList ->
            mutableData.value = datosList
        }
        return mutableData
    }

    private fun observeData() {
        fetchComandasCliente().observe(viewLifecycleOwner, Observer {
            infoClientesAdapter.setListData(it)
            infoClientesAdapter.notifyDataSetChanged()
        })
    }

    private fun getComandasCliente(): LiveData<MutableList<Usuari>> {
        val mutableData = MutableLiveData<MutableList<Usuari>>()
        val listData = mutableListOf<Usuari>()
        val uidCliente = args.currentClient.uidCliente
        Log.w("uidCliente", uidCliente)

        dbReference.orderByKey().limitToFirst(1).equalTo(uidCliente)
            .addValueEventListener(object : ValueEventListener {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { cliente ->
                        val comandaQuery =
                            cliente.key.let { dbReference.child(it!!).child("comandas") }
                        Log.w("comandaQuery", comandaQuery.toString())

                        comandaQuery.orderByKey()
                            .addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    snapshot.children.forEach { comanda ->
                                        val idComandaQuery =
                                            comanda.key.let { comandaQuery.child(it!!) }
                                        Log.w("idComandaQuery", idComandaQuery.toString())
                                        idComandaQuery.addValueEventListener(object :
                                            ValueEventListener {
                                            override fun onDataChange(snapshot: DataSnapshot) {
                                                val fechaComanda =
                                                    snapshot.child("fecha").value.toString()
                                                val estadoComanda =
                                                    snapshot.child("estado").value.toString()
                                                val costeComanda =
                                                    snapshot.child("coste").value.toString()

                                                val datosComanda = Usuari(
                                                    "", "", "", "", "", "", "", "", Comandas(
                                                        "",
                                                        estadoComanda,
                                                        costeComanda,
                                                        fechaComanda,
                                                        Producto("", "","","","",""),
                                                    )
                                                )

                                                listData.add(datosComanda)
                                                mutableData.value = listData

                                            }

                                            override fun onCancelled(error: DatabaseError) {
                                                TODO("Not yet implemented")
                                            }

                                        })
                                    }
                                }

                                override fun onCancelled(error: DatabaseError) {
                                    TODO("Not yet implemented")
                                }

                            })
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }


            })


        return mutableData
    }

}