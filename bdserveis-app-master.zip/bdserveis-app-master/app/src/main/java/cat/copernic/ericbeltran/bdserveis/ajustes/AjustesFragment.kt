package cat.copernic.ericbeltran.bdserveis.ajustes

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentAjustesBinding
import cat.copernic.ericbeltran.bdserveis.models.Comandas
import cat.copernic.ericbeltran.bdserveis.models.Producto
import cat.copernic.ericbeltran.bdserveis.models.Usuari
import cat.copernic.ericbeltran.bdserveis.registro_login.PantallaLogin
import com.google.firebase.auth.FirebaseAuth

class AjustesFragment : Fragment() {

    private lateinit var bindingAjustes: FragmentAjustesBinding

    lateinit var preferences: SharedPreferences

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentAjustesBinding.inflate(inflater, container, false)
        bindingAjustes = binding

        bindingAjustes.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        preferences = requireActivity().getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)

        bindingAjustes.logOut.setOnClickListener {
            Usuari(
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                Comandas("", "", "", "", Producto("", "", "", "", "", ""))
            )

            val editor: SharedPreferences.Editor = preferences.edit()
            editor.clear()
            editor.apply()

            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(requireContext(), PantallaLogin::class.java))
        }

        bindingAjustes.politicaPriv.setOnClickListener {
            findNavController().navigate(R.id.action_to_privacidadFragment)
        }

        bindingAjustes.informarProb.setOnClickListener {
            findNavController().navigate(R.id.action_to_informarProblemaFragment)
        }

        bindingAjustes.condiUs.setOnClickListener {
            findNavController().navigate(R.id.action_to_condicionsFragment)
        }

        return binding.root
    }

}