package cat.copernic.ericbeltran.bdserveis.tienda

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import cat.copernic.ericbeltran.bdserveis.R
import cat.copernic.ericbeltran.bdserveis.databinding.FragmentEditarTiendaBinding
import cat.copernic.ericbeltran.bdserveis.snack
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.StorageTask
import com.google.firebase.storage.UploadTask

class EditarTiendaFragment : Fragment() {

    private lateinit var bindingEditarTienda: FragmentEditarTiendaBinding

    private val args by navArgs<EditarTiendaFragmentArgs>()

    private lateinit var user: FirebaseUser
    private lateinit var dbReference: DatabaseReference
    private lateinit var adminReference: DatabaseReference
    private lateinit var tiendaReference: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private val GALLERY_PICKUP_CODE: Int = 123
    private var imageUri: Uri? = null
    private var storageRef: StorageReference? = null
    private var glbUrl = ""

    private var disponible = 0
    private var noDisponible = 0
    private var categoriaProducte = ""


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding = FragmentEditarTiendaBinding.inflate(inflater, container, false)
        bindingEditarTienda = binding

        bindingEditarTienda.btnAtras.setOnClickListener {
            getFragmentManager()?.popBackStack()
        }

        auth = FirebaseAuth.getInstance()
        user = auth.currentUser!!
        dbReference = FirebaseDatabase.getInstance().reference.child("USUARI/CLIENT")
        adminReference = FirebaseDatabase.getInstance().reference.child("USUARI/ADMINISTRADOR")
        tiendaReference = FirebaseDatabase.getInstance().reference.child("TENDA/CATEGORIA")
        storageRef = FirebaseStorage.getInstance().reference.child("TIENDA")

        bindingEditarTienda.tfCosteProducto.setText(args.currentProductoEditar.coste)
        bindingEditarTienda.tfNombreProducto.setText(args.currentProductoEditar.nombre)
        bindingEditarTienda.tfDescripcionProducto.setText(args.currentProductoEditar.descripcion)

        bindingEditarTienda.btnModificarProductoTienda.setOnClickListener {
            nuevoProducto()
        }

        bindingEditarTienda.btnImagenProdcuto.setOnClickListener {
            pickImage()
        }

        seleccionarCategoria()
        seleccionarDisponibilidad()

        return binding.root
    }

    private fun seleccionarCategoria() {
        val catAlarmas = bindingEditarTienda.categoriaAlarmes
        val catExtint = bindingEditarTienda.categoriaExtintors
        val catCamaras = bindingEditarTienda.categoriaCameras

        catAlarmas.setOnClickListener {
            categoriaProducte = "ALARMAS"

            catAlarmas.setBackgroundColor(Color.YELLOW)
            catExtint.setBackgroundColor(Color.TRANSPARENT)
            catCamaras.setBackgroundColor(Color.TRANSPARENT)
        }
        catExtint.setOnClickListener {
            categoriaProducte = "EXTINTORES"

            catAlarmas.setBackgroundColor(Color.TRANSPARENT)
            catExtint.setBackgroundColor(Color.YELLOW)
            catCamaras.setBackgroundColor(Color.TRANSPARENT)
        }
        catCamaras.setOnClickListener {
            categoriaProducte = "CAMARAS"

            catAlarmas.setBackgroundColor(Color.TRANSPARENT)
            catExtint.setBackgroundColor(Color.TRANSPARENT)
            catCamaras.setBackgroundColor(Color.YELLOW)
        }
    }

    private fun seleccionarDisponibilidad() {
        val dispo = bindingEditarTienda.txtDisponible
        val noDispo = bindingEditarTienda.txtNoDisponible

        dispo.setOnClickListener {
            dispo.setBackgroundColor(Color.GREEN)
            disponible = 1
            noDisponible = 0
            noDispo.setBackgroundColor(Color.TRANSPARENT)
        }
        noDispo.setOnClickListener {
            dispo.setBackgroundColor(Color.TRANSPARENT)
            noDisponible = 1
            disponible = 0
            noDispo.setBackgroundColor(Color.RED)
        }
    }

    private fun nuevoProducto() {
        val nombreProducto = bindingEditarTienda.tfNombreProducto.text.toString()
        val descripcionProducto = bindingEditarTienda.tfDescripcionProducto.text.toString()
        val costeProducto = bindingEditarTienda.tfCosteProducto.text.toString()
        val imagen = glbUrl

        val referenciaCategoria = tiendaReference.child(categoriaProducte)
        val idProductoFinal = args.currentProductoEditar.idProducto

        if (categoriaProducte != "") {
            if (nombreProducto.isNotEmpty() || descripcionProducto.isNotEmpty() || costeProducto.isNotEmpty()) {
                if (disponible == 0 && noDisponible != 0 || disponible != 0 && noDisponible == 0) {
                    referenciaCategoria.orderByKey().limitToFirst(1).equalTo(idProductoFinal)
                        .addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(snapshot: DataSnapshot) {

                                snapshot.children.forEach { dato ->
                                    val test = dato.key.let { referenciaCategoria.child(it!!) }

                                    test.child("nombre")
                                        .setValue(nombreProducto)
                                    test.child("descripcion")
                                        .setValue(descripcionProducto)
                                    test.child("coste")
                                        .setValue(costeProducto)
                                    test.child("imagen/imagen1")
                                        .setValue(imagen)

                                    val dispo = "Disponible"
                                    val noDispo = "No disponible"

                                    if (disponible == 1 || noDisponible == 0) {
                                        test.child("disponibilidad")
                                            .setValue(dispo)
                                    } else if (disponible == 0 || noDisponible == 1) {
                                        test.child("disponibilidad")
                                            .setValue(noDispo)
                                    }
                                }
                                findNavController().navigate(R.id.action_to_tendaFragment)
                            }

                            override fun onCancelled(error: DatabaseError) {
                                TODO("Not yet implemented")
                            }

                        })
                } else {
                    requireView().snack(getString(R.string.editarTendaDisponibilitat))
                }
            } else {
                requireView().snack(getString(R.string.editarTendaDadesBlanc))
            }
        } else {
            requireView().snack(getString(R.string.editarTendaCategoria))
        }
    }

    private fun pickImage(){
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent, GALLERY_PICKUP_CODE)
    }

    private fun uploadedImageToDatabase() {
        val progressBar = ProgressDialog(context)
        progressBar.show()

        if(imageUri!=null){
            var fileRef = storageRef!!.child(System.currentTimeMillis().toString() + ".jpg")

            var uploadTask: StorageTask<*>
            uploadTask = fileRef.putFile(imageUri!!)

            uploadTask.continueWithTask(Continuation <UploadTask.TaskSnapshot, Task<Uri>> { task ->
                if(!task.isSuccessful){
                    task.exception?.let {
                        throw it
                    }
                }
                return@Continuation fileRef.downloadUrl
            }).addOnCompleteListener{ task ->
                if (task.isSuccessful){
                    imageUri = task.result
                    glbUrl = imageUri.toString()

                    progressBar.dismiss()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GALLERY_PICKUP_CODE && resultCode == Activity.RESULT_OK && data!!.data != null){
            imageUri = data.data
            uploadedImageToDatabase()
        }

    }
}